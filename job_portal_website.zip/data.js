export const vacancies = [
    {
        id: 1,
        title: "Backend Node.js developer (middle)",
        company: "Coder's Gyan",
        city: "Moscow",
        description: "Lorem ipsum dolor sit amet consectetur, adipisicing elit. Tempora maiores veritatis, iure amet unde quod ducimus architecto corporis iusto temporibus alias debitis! Harum nobis error aliquid eveniet commodi? Expedita, perferendis."
    },
    {
        id: 2,
        title: "Frontend developer (senior)",
        company: "Flash",
        city: "Tokio",
        description: "Lorem ipsum dolor sit amet consectetur, adipisicing elit. Tempora maiores veritatis, iure amet unde quod ducimus architecto corporis iusto temporibus alias debitis! Harum nobis error aliquid eveniet commodi? Expedita, perferendis."
    },
    {
        id: 3,
        title: "Java developer (spring )",
        company: "Jcon",
        city: "Canada",
        description: "Lorem ipsum dolor sit amet consectetur, adipisicing elit. Tempora maiores veritatis, iure amet unde quod ducimus architecto corporis iusto temporibus alias debitis! Harum nobis error aliquid eveniet commodi? Expedita, perferendis."
    }
]