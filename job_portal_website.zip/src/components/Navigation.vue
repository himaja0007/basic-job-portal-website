<template>
    <nav class="navbar" role="navigation" aria-label="main navigation">
  <div class="navbar-brand">
    <a class="navbar-item logo" href="/">
      JOB PORTAL 
    </a>

    <a role="button" class="navbar-burger" aria-label="menu" aria-expanded="false" data-target="navbarBasicExample">
      <span aria-hidden="true"></span>
      <span aria-hidden="true"></span>
      <span aria-hidden="true"></span>
    </a>
  </div>

  <div id="navbarBasicExample" class="navbar-menu">
    <div class="navbar-start">
      <router-link to="/" class="navbar-item">
        Home
      </router-link>
      
      <router-link to="/posts" class="navbar-item">
        Posts
      </router-link>
    </div>

    <div class="navbar-end">
      <div class="navbar-item">
        <div class="buttons">
          <a class="button is-primary" onclick="alert('Sign up soon...')">
            <strong>Sign up</strong>
          </a>
          <a class="button is-light" onclick="alert('Log in soon...')">
            Log in
          </a>
        </div>
      </div>
    </div>
  </div>
</nav>
</template>

<script>
    export default {

    }
</script>

<style>

  .logo{
    font-size: 20px;
    font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;
    font-weight: bold;
  }
  .navbar{
    background-color: #b9b9c5;
    padding:1%;
  }
  .navbar-item:hover{
    /* border: 5px solid black; */
    border-radius: 5px;
  }
</style>